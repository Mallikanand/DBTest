package com.db.test;

import static com.db.test.drawring.ShapesFactory.getShape;

import java.util.Scanner;

import com.db.test.drawring.Canvas;
import com.db.test.drawring.Shape.ShapeType;

public class DrawingMain {
	
	private Canvas canvas = null;
	private InputValidator validator = null;
	
	public static void main(String args []){
		DrawingMain d = new DrawingMain();
		d.setup();
	}

	public void setup(){
		try(Scanner s = new Scanner(System.in)){
			processInstructions(s);
		}
	}

	private void processInstructions(Scanner s) {
		boolean goodBye = false;
		String instruction;
		
		System.out.println("Enter Your Command:");
		instruction = s.nextLine();

		validator = this.new InputValidator();
		
		if(!validator.validateInstructionReceived(instruction))
			throwNewUsageError();
		else if(isCommandNotCreateCanvas(getCommand(instruction)))
			throwFirstCommandNotCreateCanvas();
		else if(isCommandCreateCanvas(getCommand(instruction))){
			try{
				canvas = new Canvas(Integer.parseInt(this.getFirstCommandArgument(instruction)),
					 				Integer.parseInt(this.getSecondCommandArgument(instruction)));
				}catch(Exception e){
					System.out.println(e.getMessage());
				}
		}else if(isCommandQuit(getCommand(instruction))){
			System.out.println("Good Bye!");
			goodBye = true;
			
		}
		
		while(!goodBye){
			System.out.println("Enter Your Next Command:");
			instruction = s.nextLine();
			
			if(!validator.validateInstructionReceived(instruction))
				throwNewUsageError();
			else if(canvas == null && isCommandNotCreateCanvas(getCommand(instruction)))
				throwFirstCommandNotCreateCanvas();
			else{
				switch (this.getCommand(instruction)){
					case "C": 
						prepareCanvas(instruction);
						break;
					case "L": 
						drawAShape(instruction,ShapeType.LINE);
						break;
					case "R":
						drawAShape(instruction, ShapeType.RECTANGLE);
						break;
					case "Q":
						System.out.println("Good Bye!");
						goodBye=true;
				}
			}
		}
	}

	private void drawAShape(String instruction, ShapeType type) {
		try{
			canvas.addShapeOnCanvas(getShape(type,canvas,
							getFirstCommandArgument (instruction),
						 	getSecondCommandArgument(instruction),
							getThirdCommandArgument (instruction),
						 	getFourthCommandArgument(instruction)
				 			));
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}

	private void prepareCanvas(String instruction) {

		if(canvas != null && isCommandCreateCanvas(getCommand(instruction)))
			throwCanvasAlreadyCreated();
		else{
			try{
				canvas = new Canvas(	Integer.parseInt(this.getFirstCommandArgument(instruction)),
					 	Integer.parseInt(this.getSecondCommandArgument(instruction)));
			}catch(Exception e){
				System.out.println(e.getMessage());
			}
		}
	}

	private void throwFirstCommandNotCreateCanvas() {
		final String USAGE = 
				"The first command has to be a \"C\"";
		
		System.out.println(USAGE);
	}

	private void throwCanvasAlreadyCreated() {
		final String USAGE = 
				"Canvas Already created.. Start Drawing on It using L - for Line, R - Rectangle ..";
		
		System.out.println(USAGE);
	}

	private String getCommand(String instruction) {
		return instruction.split("\\s+")[0];
	}
	
	private String getFirstCommandArgument(String instruction) {
		return instruction.split("\\s+")[1];
	}
	
	private String getSecondCommandArgument(String instruction) {
		return instruction.split("\\s+")[2];
	}

	private String getThirdCommandArgument(String instruction) {
		return instruction.split("\\s+")[3];
	}
	
	private String getFourthCommandArgument(String instruction) {
		return instruction.split("\\s+")[4];
	}
	
	public boolean isCommandCreateCanvas(String cmd) {
		return cmd.equals("C");
	}

	public boolean isCommandNotCreateCanvas(String cmd) {
		return !isCommandCreateCanvas(cmd);
	}

	public boolean isCommandQuit(String cmd) {
		return cmd.equals("Q");
	}


	class InputValidator{
		public boolean validateInstructionReceived(String instruction) {
			return instruction != null && isNotWellFormatted(instruction);
		}

		private boolean isNotWellFormatted(String instruction) {
			final String SPACES = "\\s+";
			String[] arguments = instruction.split(SPACES);
			if(arguments.length < 1) 
				return false;
			
			if( !(arguments[0].equals("C") 
					|| arguments[0].equals("L") 
					|| arguments[0].equals("R")
					|| arguments[0].equals("Q")) )
				return false;
			
			if(arguments[0].equals("Q") && arguments.length > 1 )
				return false;
			
			if(arguments[0].equals("C")){
				if(arguments.length != 3)
					return false;
				try{
					Integer.parseInt(arguments[1]);
					Integer.parseInt(arguments[2]);
				}catch(NumberFormatException e){
					return false;
				}
			}
			
			if(arguments[0].equals("L") || arguments[0].equals("R")){
				if(arguments.length != 5)
					return false;
				try{
					Integer.parseInt(arguments[1]);
					Integer.parseInt(arguments[2]);
					Integer.parseInt(arguments[3]);
					Integer.parseInt(arguments[4]);
				}catch(NumberFormatException e){
					return false;
				}
			}
			return true;
		}
	}
	
	private void throwNewUsageError() {

		final String USAGE = 
				"\n\n INVALID COMMAND. \n\n"
				+ "USAGE\n"
				+ "-----"
				+ "\n\n<COMMAND> [COORDINATES] \n"
				+ "where COMMAND is one of \n"
				+ "C,width,height \n"
				+ "L,x1,y1,x2,y2 \n"
				+ "R,x1,y1,x2,y2 \n"
				+ "COORDINATES specific to the COMMAND \n"
				+ "Or Simply a \"Q\" to QUIT";
		
		System.out.println(USAGE);
		
		//System.exit(-1);
				
	}

}
