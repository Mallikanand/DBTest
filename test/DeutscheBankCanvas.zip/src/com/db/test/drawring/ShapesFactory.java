package com.db.test.drawring;

import com.db.test.drawring.Canvas;
import com.db.test.drawring.Line;
import com.db.test.drawring.Rectangle;
import com.db.test.drawring.Shape;
import com.db.test.drawring.Shape.ShapeType;

public class ShapesFactory {

	public static Shape getShape(ShapeType type, Canvas canvas, String x1, String y1,String x2, String y2){
		
		switch(type){
			case LINE :
				return new Line(canvas,
						Integer.parseInt(x1),
					 	Integer.parseInt(y1),
						Integer.parseInt(x2),
					 	Integer.parseInt(y2)
			 			);
			case RECTANGLE:
				return new Rectangle(canvas,
						Integer.parseInt(x1),
					 	Integer.parseInt(y1),
						Integer.parseInt(x2),
					 	Integer.parseInt(y2)
			 			);
		}
		throw new IllegalArgumentException("Invalid Shape requested.. ");
	}
}
