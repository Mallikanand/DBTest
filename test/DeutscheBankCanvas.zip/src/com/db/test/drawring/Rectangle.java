package com.db.test.drawring;

public class Rectangle extends LinearShape{
	
	Rectangle(Canvas canvas, int x1, int y1, int x2, int y2){
		super(canvas,x1,y1,x2,y2);
	}
	
	@Override
	public void draw() {
		drawHorizontalLine();
		drawVerticalLine();
	}

	@Override
	protected void drawHorizontalLine(){
		
		if(left.x <= right.x){
			for(int i=left.x;i<=right.x;i++)
				canvas.getCanvas()[left.y][i] = canvas.getCanvas()[right.y][i] = CHAR;
		}else{
			for(int i=right.x;i<=left.x;i++)
				canvas.getCanvas()[left.y][i] = canvas.getCanvas()[right.y][i] = CHAR;
		}
	}
	
	@Override
	protected void drawVerticalLine(){
		if(left.y<=right.y){//draw from here to there
			for(int i=left.y;i<=right.y;i++)
				canvas.getCanvas()[i][left.x] = canvas.getCanvas()[i][right.x] = CHAR;
		}else{//or draw from there to here ..
			for(int i=right.y;i<=left.y;i++)
				canvas.getCanvas()[i][left.x] = canvas.getCanvas()[i][right.x] = CHAR;

		}
	}
}
