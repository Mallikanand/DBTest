package com.db.test.drawring;

public interface Shape {
	
	public void draw();

	public enum ShapeType{
		
		LINE ("A Line"), 
		RECTANGLE("A Rectangle");
		
		ShapeType(String desc){
		}
	}

}
