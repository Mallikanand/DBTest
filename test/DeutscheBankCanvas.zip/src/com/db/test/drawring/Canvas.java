package com.db.test.drawring;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.IntStream;

public class Canvas {

	private int columns; 
	private int rows;
	
	private final static int HORIZONTAL_BOUNDARY=2;
	private final static int VERTICAL_BOUNDARY=2;
	
	private char[][] canvas = null;
	private List<Shape> shapes;	
	
	public Canvas(int width, int height){
		
		if(width<=0 || height<= 0) throw new IllegalArgumentException("Canvas has to have valid boundaries..");
		
		this.columns = width+HORIZONTAL_BOUNDARY;
		this.rows = height+VERTICAL_BOUNDARY;
		
		canvas = new char[rows][columns];
		shapes = new ArrayList<>();
		
		initCanvas();
	}
	
	private void draw(){
		shapes.forEach(s->s.draw());
		printCanvas();
	}
	
	public void addShapeOnCanvas(Shape s){
		if(s!=null){
			shapes.add(s);
			draw();
		}else
			throw new IllegalArgumentException("Shape has to be valid");
	}

	private void initCanvas() {
		
		drawHorizontalBoundaries();
		
		IntStream.range(1,rows-1)
			.forEach(i->{
				canvas[i] = new char[columns];
				drawVerticalBoundaries(canvas[i]);
				});
		
		printCanvas();
		
	}
	
	private void printCanvas(){
		for(int i=0; i<rows; i++){
			for(int j=0; j< columns; j++){
				System.out.print(canvas[i][j]);
			}
			System.out.println();
		}
	}

	private void drawHorizontalBoundaries() {
		
		char[] topHLine 	= new char[columns];
		char[] bottomHLine 	= new char[columns];
		
		canvas[0] = topHLine;
		canvas[rows-1] = bottomHLine;
		
		IntStream.range(0, columns).forEach(i->{topHLine[i] = bottomHLine[i] = '-';});
	}
	
	private void drawVerticalBoundaries(char[] row){
		
		IntStream.range(0, columns)
		.forEach(i -> {
			if(i==0||i==columns-1)
				row[i]='|';
			else
				row[i]=' ';
		});
	}

	public char[][] getCanvas() {
		return canvas;
	}

	public void setCanvas(char[][] canvas) {
		this.canvas = canvas;
	}
	
	public int getWidth(){
		return columns-HORIZONTAL_BOUNDARY;
	}
	public int getHeight(){
		return rows-VERTICAL_BOUNDARY;
	}

	public List<Shape> getShapes() {
		return Collections.unmodifiableList(shapes);
	}
}
