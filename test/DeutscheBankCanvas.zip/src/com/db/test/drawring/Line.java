package com.db.test.drawring;

public class Line extends LinearShape{
	
	Line(Canvas canvas, int x1, int y1, int x2, int y2){
		super(canvas,x1,y1,x2,y2);
		if( ! ((x1==x2) || (y1==y2)) )
			throw new IllegalArgumentException("Only trained to draw horizontal and vertical lines, not diagnols");
	}
	
	@Override
	public void draw() {
		
		if(left.y == right.y){
			drawHorizontalLine();
		}else if(left.x == right.x){
			drawVerticalLine();
		}
	}

	@Override
	protected void drawHorizontalLine() {
		
		if(left.x <= right.x){ //draw from left to right
			for(int i=left.x;i<=right.x;i++)
				canvas.getCanvas()[left.y][i] = CHAR;
		}
		else{//draw from right to left
			for(int i=right.x;i<=left.x;i++)
				canvas.getCanvas()[left.y][i] = CHAR;
		}
	}

	@Override
	protected void drawVerticalLine() {
		
		if(left.y<=right.y){//draw from top to bottom
			for(int i=left.y;i<=right.y;i++)
				canvas.getCanvas()[i][left.x] = CHAR;
		}else{//draw from bottom to top
			for(int i=right.y;i<=left.y;i++)
				canvas.getCanvas()[i][left.x] = CHAR;

		}
	}

}
