package com.db.test.drawring;

import java.awt.Point;

public abstract class LinearShape implements Shape {

	protected static final char CHAR = 'x';

	protected Point left;
	protected Point right;
	protected Canvas canvas;
	
	public LinearShape(Canvas canvas, int x1, int y1, int x2, int y2){
		
		if( (x1<0 ||y1<0 ||x2<0 ||y2<0)
				|| (x1 > canvas.getWidth() || x2 > canvas.getWidth())
				|| (y1 > canvas.getHeight() || y2 > canvas.getHeight()) )
			throw new IllegalArgumentException("Co-ordinates not with-in canvas boundaries");
				
		left = new Point(x1,y1);
		right = new Point(x2,y2);
		
		this.canvas = canvas;
	}
	
	protected abstract void drawHorizontalLine();
	protected abstract void drawVerticalLine();

}
