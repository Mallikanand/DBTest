package com.db.test;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.db.test.DrawingMain.InputValidator;

public class InputValidatorTest {

	InputValidator validator = null;
	
	@Before
	public void setup(){
		DrawingMain d = new DrawingMain();
		validator = d.new InputValidator();
	}
	
	@Test
	public void test_input_null(){
		Assert.assertFalse(validator.validateInstructionReceived(null));
	}
	
	@Test
	public void test_input_BAD_COMMAND(){
		Assert.assertFalse(validator.validateInstructionReceived("B 10 20"));
	}
	
	@Test 
	public void test_input_BAD_COORDINATES(){
		Assert.assertFalse(validator.validateInstructionReceived("Q 10 20"));
		Assert.assertFalse(validator.validateInstructionReceived("C m y"));
		Assert.assertFalse(validator.validateInstructionReceived("C 10 asdf"));
		Assert.assertFalse(validator.validateInstructionReceived("L 10 20"));
		Assert.assertFalse(validator.validateInstructionReceived("R 10 20"));
		
	}
	
	@Test
	public void test_input(){
		Assert.assertTrue(validator.validateInstructionReceived("C  10   20"));
		Assert.assertTrue(validator.validateInstructionReceived("C 10 20"));
		Assert.assertTrue(validator.validateInstructionReceived("L 10 20 20 30"));
		Assert.assertTrue(validator.validateInstructionReceived("R 10 20 20 30"));
	}
}
