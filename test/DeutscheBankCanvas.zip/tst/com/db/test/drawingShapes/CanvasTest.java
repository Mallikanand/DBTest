package com.db.test.drawingShapes;

import static com.db.test.drawring.ShapesFactory.getShape;

import org.junit.Assert;
import org.junit.Test;

import com.db.test.drawring.Canvas;
import com.db.test.drawring.Shape.ShapeType;

public class CanvasTest {
	

	@Test
	public void test_BoundaryConditions(){
		
		Canvas canvas;
		try{
			canvas = new Canvas(0,0);
			Assert.fail();
		}catch(Exception e){
			//good
		}
		
		try{
			canvas = new Canvas(-1,0);
			Assert.fail();
		}catch(Exception e){
			//good
		}
		
		try{
			canvas = new Canvas(0,-1);
			Assert.fail();
		}catch(Exception e){
			//good
		}
		
		canvas = new Canvas(20,5);
		try{
			canvas.addShapeOnCanvas(getShape(ShapeType.LINE, canvas,"1","3","7","6"));
			Assert.fail();
		}catch(Exception e){
			//good. ensure Canvas was not drawn on.. 
			Assert.assertTrue(e.getMessage(),canvas.getShapes().size() == 0);
		}
		
		try{
			canvas.addShapeOnCanvas(getShape(ShapeType.LINE, canvas,"7","3","21","3"));
			Assert.fail();
		}catch(Exception e){
			//good. ensure Canvas was not drawn on.. 
			Assert.assertTrue(e.getMessage(),canvas.getShapes().size() == 0);
		}
		
		try{
			canvas.addShapeOnCanvas(getShape(ShapeType.LINE, canvas,"1","3","2","5"));
			Assert.fail();
		}catch(Exception e){
			//good. ensure Canvas was not drawn on.. 
			Assert.assertTrue(e.getMessage(),canvas.getShapes().size() == 0);
		}
	}
	
	@Test
	public void test_normal(){
		
		Canvas canvas = new Canvas(20,5);
		canvas.addShapeOnCanvas(getShape(ShapeType.LINE, canvas, "1","3","7","3"));
		canvas.addShapeOnCanvas(getShape(ShapeType.LINE, canvas, "7","1","7","3"));
		
		canvas.addShapeOnCanvas(getShape(ShapeType.RECTANGLE, canvas,"15","2","20","5"));

		Assert.assertTrue(canvas.getShapes().size() == 3);
		
		canvas.addShapeOnCanvas(getShape(ShapeType.LINE, canvas,"5","1","12","1"));
		Assert.assertTrue(canvas.getShapes().size() == 4);
	}

	@Test
	public void test_DrawingLines_In_Reverse(){
	
		Canvas canvas = new Canvas(20,5);
		canvas.addShapeOnCanvas(getShape(ShapeType.LINE, canvas, "7","3","1","3"));
		canvas.addShapeOnCanvas(getShape(ShapeType.LINE, canvas, "7","5","7","1"));
		canvas.addShapeOnCanvas(getShape(ShapeType.RECTANGLE, canvas, "20","5","15","2"));
		
		Assert.assertTrue(canvas.getShapes().size() == 3);
	}
	
}
